// 1. Fiz tudo e consegui entender bem esses conceitos iniciais, consegui acompanhar na aula.
// 2. Fiz junto com o senhor durante a aula e em casa tentei refazer e consegui, mas eu peguei todos os conceitos.
// 3. entendi o inicio de java pra objetos ate que bem, to estudando pra aprender a logica de organizar as informacoes
// 4. levei o tempo da aula e em casa em torno de 2h pra refazer e entender os conteudos.
import java.util.Scanner;

class Aluno {
    String nome;
    float notas[];
    
    void ler() {
        nome = input();
        notas = new float[3];
        for (int i=0; i<3; i++) {
            notas[i] = Float.parseFloat( input() );
        }
    }
    
    float media() {
        float soma = 0;
         for (int i=0; i<3; i++) {
            float nota = notas[i];
       // for (float nota : notas) {
            soma += nota;
        }
        float med = soma/3;
        return med;
    }

    Scanner scan = new Scanner(System.in);
    String input() { return scan.nextLine(); }
}

class NovaMedia {
    public static void main(String args[]) {
        Aluno alu = new Aluno();
        alu.ler();
        float med = alu.media();
        System.out.printf("%.2f",med);
    }
}

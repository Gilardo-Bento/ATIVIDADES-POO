import java.text.DecimalFormat;
 import java.util.Scanner;
 import java.util.ArrayList;

 class Slot {
     private String name;
    private float price;
     private int quantity;
    
     public Slot( String name, float price, int quantity ) {
         this.name = name;
         this.price = price;
         this.quantity = quantity;
     }
    
     public void setName( String name ) {
         this.name = name;
     }
     public void setPrice( float price ) {
         this.price = price;
     }
     public void setQuantity( int quantity ) {
         this.quantity = quantity;
     }

     public String getName() {
         return this.name;
     }
     public float getPrice() {
         return this.price;
    }
     public int getQuantity() {
         return this.quantity;
     }

     public String toString() {
         return String.format("%8s",this.name) + " : " +
               this.quantity + " U : " +
               Solver.decForm.format(this.price) + " RS";
     }
 }

 class VendingMachine {
     private ArrayList<Slot> slots;
     private float profit;  //lucro
     private float cash;    //dinheiro
     private int capacity;  //capacidade
    
     public VendingMachine( int capacity ) {
         this.capacity = capacity;
         slots = new ArrayList<Slot>();
         for (int i=0; i<capacity; i++) {
             slots.add( new Slot("empty",0,0) );
         }
     }
     
     
     

   /*  private boolean indiceInvalido( int ind ) {
         if ( ind < 0 || ind >= this.slots.size() ) {
            // if (ind < slots.size() && ind >= 0){
             System.out.println("fail: indice nao existe");
             return true;
         }
         return false;
     }
*/
        private boolean indiceInvalido( int ind ){
            if( ind >= this.slots.size() ||  ind < 0 ){
            System.out.println("fail: indice nao existe");
                 return true ;  
            }   
            return false;
        }
        
     public Slot getSlot( int ind ) {
         if ( this.indiceInvalido(ind) ) {
             return null;
         }

         return this.slots.get(ind);
     }
     public void setSlot( int ind, Slot slot ) {
         if ( this.indiceInvalido(ind) ) {
             return;
         }

         this.slots.set(ind, slot);
     }
     public void clearSlot( int ind ) {  //limpar slot
         if ( this.indiceInvalido(ind) ) {
             return;
         }

         this.setSlot( ind, new Slot("empty",0,0) );
         // Slot slot = this.slots.get(ind);
         // slot.setName("empty");
         // slot.setPrice(0);
         // slot.setQuantity(0);
     }

     public void insertCash( float cash ) {  //inserir dinheiro
         this.cash += cash;
     }
     
     public float withdrawCash() {  //retirar o dinheiro
         System.out.println("voce recebeu " + Solver.decForm.format(this.cash) + " RS");

         float cash = this.cash;
         this.cash = 0;
         return cash;
     }
     public float getCash() {
         return this.cash;
     }
     public float getProfit() {
         return this.profit;


     }

     public void buyItem( int ind ) {   //comprar item
         if ( this.indiceInvalido(ind) ) {
             return;
         }

         Slot item = this.slots.get(ind);
         if ( item.getQuantity() == 0 ) {
             System.out.println("fail: espiral sem produtos");
             return;
         }

         if ( this.cash < item.getPrice() ) {
             System.out.println("fail: saldo insuficiente");
             return;
         }

         System.out.println( "voce comprou um " + item.getName() );
         item.setQuantity( item.getQuantity() - 1 );
         this.cash -= item.getPrice();
         this.profit += item.getPrice();
     }

     public String toString() {
         String s = "saldo: " + Solver.decForm.format(this.cash) + "\n";
         for (int i=0; i<this.slots.size(); i++) {
             Slot slot = this.getSlot(i);
             s += i + " [" + slot + "]\n";
         }
         return s;
     }
 }

 class Solver {
     public static void main (String[] args) {
         VendingMachine machine = new VendingMachine(0);
        
         while( true ) {
             String linha = input();
             String[] palavras = linha.split(" ");
             println("$" + linha);

             if ( palavras[0].equals("end") ) { break; }
             else if ( palavras[0].equals("init")     ) { machine = new VendingMachine( Integer.parseInt(palavras[1]) ); }
             else if ( palavras[0].equals("show")     ) { print(machine); }
             else if ( palavras[0].equals("set")      ) { machine.setSlot( Integer.parseInt(palavras[1]), new Slot( palavras[2], Float.parseFloat(palavras[4]), Integer.parseInt(palavras[3]) ) ); }
             else if ( palavras[0].equals("limpar")   ) { machine.clearSlot( Integer.parseInt(palavras[1]) ); }
             else if ( palavras[0].equals("dinheiro") ) { machine.insertCash( Integer.parseInt(palavras[1]) ); }
             else if ( palavras[0].equals("troco")    ) { machine.withdrawCash(); }
             else if ( palavras[0].equals("comprar")  ) { machine.buyItem( Integer.parseInt(palavras[1]) ); }
             else if ( palavras[0].equals("apurado")  ) { println( "apurado total: " + decForm.format(machine.getProfit()) ); }
             else { println("comando inválido!"); }
         }
     }

     public static Scanner scan = new Scanner(System.in);
     public static String input() { return scan.nextLine();            }
     public static void println(Object str) { System.out.println(str); }
     public static void print(Object str) { System.out.print(str);     }
     public static DecimalFormat decForm = new DecimalFormat("0.00");
 }

/*
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

 
class Slot {
    private String name;
    private double price;
    private int qtd;

    public Slot(String name, double price, int qtd) {
        this.name = name;
        this.price = price;
        this.qtd = qtd;
    }

    public int getQtd() {
        return this.qtd;
    }

    public double getPrice() {
        return this.price;
    }

    public void setQtd(int qtd) {
        this.qtd = qtd;
    }

    public String getName() {
        return this.name;
    }

    public String toString() {
        return String.format("[%8s :%2d U : %.2f RS]", name, qtd, price);
    }
}

class Machine {
    private List<Slot> espirais;
    private double saldo=0.0;
    private double profit; //lucro
    
    public Machine(int qtd) {
        espirais = new ArrayList<>(qtd);
        for (int i = 0; i < qtd; i++) {
            espirais.add(new Slot("empty", 0.0, 0));
        }
       // saldo = 0.0;
    }
   public double getProfit() {
        return profit;
    }
//Alterar o valor do slot 
    public void setSlot(int index, String nome, int qtd, double value) {
        if (!validarIndex(index))
            return;
        espirais.set(index, new Slot(nome, value, qtd));
    }
//validar o indice se existe na maquina
    public boolean validarIndex(int index) {
        if (index < espirais.size() && index >= 0)
            return true;
        System.out.println("fail: indice nao existe");
        return false;
    }

//insert Cash --- adicionar dinheiro
    public void dinheiro(double value) {
        saldo += value;
    }
//withdraw --- retirar o troco 
    public double pegarTroco() {
        double troco = saldo;
        saldo = 0;
        return troco;
    }
    
//limpar a maquina e reinicia com novos valores
 public void limpar(int index) {
        if (!validarIndex(index))
            return;
        espirais.set(index, new Slot("empty", 0.0, 0));
    }
    
    public void comprar(int index) {
        if (!validarIndex(index))
            return;
        if (espirais.get(index).getQtd() == 0) {
            System.out.println("fail: espiral sem produtos");
            return;
        }
        if (espirais.get(index).getPrice() > saldo) {
       System.out.println("fail: saldo insuficiente");
            return;
        }
        saldo -= espirais.get(index).getPrice();
        espirais.get(index).setQtd(espirais.get(index).getQtd() - 1);
        profit += espirais.get(index).getPrice(); // Incrementa o lucro de acordo com as vendas.
        System.out.println("voce comprou um " + espirais.get(index).getName());
    }

    public String toString() {
        StringBuilder result = new StringBuilder("saldo: " + String.format("%.2f", saldo) + "\n");
        for (int i = 0; i < espirais.size(); i++) {
            result.append(i).append(" ").append(espirais.get(i)).append("\n");
        }
        return result.toString();
    }
}

public class Solver {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Machine machine = null;

        while (true) {
            String line = scanner.nextLine();
            String[] arguments = line.split(" ");
            System.out.println("$" + line);

            if (arguments[0].equals("end")) {
                break;
            } else if (arguments[0].equals("init")) {
                machine = new Machine(Integer.parseInt(arguments[1]));
            } else if (arguments[0].equals("show")) {
                if (machine != null) {
                    System.out.print(machine);
                }
            } else if (arguments[0].equals("set")) {
                if (machine != null) {
                    int index = Integer.parseInt(arguments[1]);
                    String name = arguments[2];
                    int qtd = Integer.parseInt(arguments[3]);
                    double price = Double.parseDouble(arguments[4]);
                    machine.setSlot(index, name, qtd, price);
                }
            } else if (arguments[0].equals("limpar")) {
                if (machine != null) {
                    int index = Integer.parseInt(arguments[1]);
                    machine.limpar(index);
                }
            } else if (arguments[0].equals("dinheiro")) {
                if (machine != null) {
                    double quantia = Double.parseDouble(arguments[1]);
                    machine.dinheiro(quantia);
                }
            } else if (arguments[0].equals("comprar")) {
                if (machine != null) {
                    int index = Integer.parseInt(arguments[1]);
                    machine.comprar(index);
                }
            } else if (arguments[0].equals("troco")) {
                if (machine != null) {
                    System.out.println("voce recebeu " + String.format("%.2f RS", machine.pegarTroco()));
                }
            }else if ( arguments[0].equals("apurado")) { 
                if(machine!=null){
               System.out.println( "apurado total: " + String.format("%.2f",machine.getProfit()) ); 
                
                }
            }
            else {
                System.out.println("fail: comando invalido");
            }
        }

        scanner.close();
    }
}

*/


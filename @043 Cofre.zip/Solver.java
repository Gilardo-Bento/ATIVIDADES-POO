// 1. Essa questao nao consegui fazer direito sozinho professor, precisei ir acompanhado a que foi feita em sala, fiquei confuso e tive que consultar a resolucao
//fiz tudo mas nao tava entendendo para fazer as extrações de fato, assisti algumas aulas para pegar o conceito.
//por isso ate demorei pegar a logica dessa questao.
// 3. entendi o inicio ate bem mas depois fiquei confuso ainda , to estudando pra aprender a logica de organizar as informacoes
// 4. levei o tempo da aula e em casa em torno de 5h pra refazer e buscar entender os conteudos novos repassados.
import java.text.DecimalFormat;
import java.util.*;
enum Coin implements Valuable {
    M10 ( 0.10, 1, "M10" ),
    M25 ( 0.25, 2, "M25" ),
    M50 ( 0.50, 3, "M50" ),
    M100( 1.00, 4, "M100");

    private double value;
    private int volume;
    private String label;

    private Coin(double value, int volume, String label) {
        this.value = value;
        this.volume = volume;
        this.label = label;
    }
    
    public double getValue() {
        return this.value;
    }
    public int getVolume() {
        return this.volume;
    }
    public String getLabel() {
        return this.label;
    }
    
    @Override
    public String toString() {
        // 0.10:1
        DecimalFormat d = new DecimalFormat("0.00");
        return this.label + ":" + d.format(this.value) + ":" + this.volume;
    }
}
 class ExtractException extends Exception {
    private ArrayList<String> labels;
    
    public ExtractException(String message, ArrayList<String> labels) {
        super(message);
        this.labels = labels;
    }
    
    ArrayList<String> getLabels() {
        return this.labels;
    }

    @Override
    public String getMessage() {
        return "fail: you must break the pig first";
    }
}

class BrokenException extends Exception {
    @Override
    public String getMessage() {
        return "fail: the pig is broken";
    }
}

class FullException extends Exception {
    @Override
    public String getMessage() {
        return "fail: the pig is full";
    }
}
class Item implements Valuable {

    private String label;
    private int volume;
    private double value;

    public Item(String label, int volume, double value) {
        this.label = label;
        this.volume = volume;
        this.value = value;
    }

    public String getLabel() {
        return this.label;
    }

    public int getVolume() {
        return this.volume;
    }

    public double getValue() {
        return this.value;
    }

    @Override
    public String toString() {
        // 0.10:1
        DecimalFormat d = new DecimalFormat("0.00");
        return this.label + ":" + d.format(this.value) + ":" + this.volume;
    }
}


class Pig {

    private boolean broken;
    // private List<Coin> coins;
    // private List<Item> items;
    private List<Valuable> valuables;
    private int volumeMax;

    public Pig(int volumeMax) {
        this.broken = false;
        // this.coins = new ArrayList<Coin>();
        // this.items = new ArrayList<Item>();
        this.valuables = new ArrayList<Valuable>();
        this.volumeMax = volumeMax;
    }

    public Coin createCoin(String valor) {
        switch (valor) {
            case "10":
                return Coin.M10;
            case "25":
                return Coin.M25;
            case "50":
                return Coin.M50;
            case "100":
                return Coin.M100;
            default:
                return null;
        }
    }

    // public boolean addCoin(Coin coin) throws Exception {
    //     if (isBroken()) {
    //         throw new BrokenException();
    //     }

    //     if (coin.getVolume() > this.getVolumeRestante()) {
    //         throw new FullException();
    //     }
        
    //     this.coins.add( coin );
    //     return true;
    // }

    // public boolean addItem(Item item) throws Exception {
    //     if (isBroken()) {
    //         throw new BrokenException();
    //     }

    //     if (item.getVolume() > this.getVolumeRestante()) {
    //         throw new FullException();
    //     }

    //     this.items.add( item );
    //     return true;
    // }

    public boolean addValuable(Valuable valuable) throws Exception {
        if (isBroken()) {
            throw new BrokenException();
        }

        if (valuable.getVolume() > this.getVolumeRestante()) {
            throw new FullException();
        }
        
        this.valuables.add( valuable );
        return true;
    }

    public boolean breakPig() throws Exception {
        if (isBroken()) {
            throw new BrokenException();
        }

        this.broken = true;
        return true;
    }

    public ArrayList<String> extractCoins() throws Exception {
        if (!this.isBroken()) {
            throw new ExtractException("fail: you must break the pig first", new ArrayList<String>());
        }
        
        ArrayList<String> labels = new ArrayList<String>();
        // for (Coin c : this.coins) {
        //     labels.add( c.toString() );
        // }
        for (Valuable v : this.valuables) {
            if ( v instanceof Coin ) { // se for uma moeda
                labels.add( v.toString() );
            }
        }
        // this.coins.clear();
        ArrayList<Valuable> items = new ArrayList<Valuable>();
        for (Valuable v : this.valuables) {
            if ( v instanceof Item ) {
                items.add( v );
            }
        }
        this.valuables = items;
        return labels;
    }

    public ArrayList<String> extractItems() throws Exception {
        if (!this.isBroken()) {
            throw new ExtractException("fail: you must break the pig first", new ArrayList<String>());
        }

        ArrayList<String> labels = new ArrayList<String>();
        // for (Item i : this.items) {
        //     labels.add( i.toString() );
        // }
        for (Valuable v : this.valuables) {
            if ( v instanceof Item ) { // se for um item
                labels.add( v.toString() );
            }
        }
        // this.items.clear();
        ArrayList<Valuable> coins = new ArrayList<Valuable>();
        for (Valuable v : this.valuables) {
            if ( v instanceof Coin ) {
                coins.add( v );
            }
        }
        this.valuables = coins;
        return labels;
    }

    // [][] : 0.00$ : 0/20 : intact
    // state=intact : coins=[] : items=[] : value=0.00 : volume=0/20
    //                coins=[0.10:1, 0.50:3]
    @Override
    public String toString() {
        String s = "";
        // s += this.coins;
        // s += this.items;
        s += this.valuables;
        DecimalFormat d = new DecimalFormat("0.00");
        s += " : " + d.format(this.calcValue()) + "$";
        s += " : " + this.getVolume() + "/" + this.getVolumeMax() + " : ";
        s += ( this.isBroken() ) ? "broken" : "intact";
        
        return s;
    }

    public int getVolume() {
        if (isBroken()) {
            return 0;
        }

        int volume = 0;
        // for (Coin c : this.coins) {
        //     volume += c.getVolume();
        // }
        // for (Item i : this.items) {
        //     volume += i.getVolume();
        // }
        for (Valuable v : this.valuables) {
            volume += v.getVolume();
        }
        return volume;
    }

    // public double getValue() {
    //     double value = 0;
    //     for (Coin c : this.coins) {
    //         value += c.getValue();
    //     }
    //     return value;
    // }

    public double calcValue() {
        double value = 0;
        for (Valuable v : this.valuables) {
            value += v.getValue();
        }
        return value;
    }

    public int getVolumeMax() {
        return this.volumeMax;
    }

    public int getVolumeRestante() {
        return this.getVolumeMax() - this.getVolume();
    }

    public boolean isBroken() {
        return this.broken;
    }
}
interface Valuable {

    public double getValue();
    public int getVolume();
    public String getLabel();

    // @Override
    public String toString();
}

public class Solver {
    public static void main(String[] arg) {
        Pig pig = new Pig(5);

        while (true) {
            String line = input();
            println("$" + line);
            String[] args = line.split(" ");

            try {
                if      (args[0].equals("end"))          { break; }
                else if (args[0].equals("init"))         { pig = new Pig( (int) number(args[1]) ); }
                else if (args[0].equals("show"))         { println(pig); }
                else if (args[0].equals("addCoin"))      { pig.addValuable( pig.createCoin( args[1] ) ); }
                else if (args[0].equals("addItem"))      { pig.addValuable( new Item( args[1], (int) number(args[3]), number(args[2]) ) ); }
                else if (args[0].equals("break"))        { pig.breakPig(); }
                else if (args[0].equals("extractCoins")) { println("[" + String.join(", ", pig.extractCoins()) + "]"); }
                else if (args[0].equals("extractItems")) { println("[" + String.join(", ", pig.extractItems()) + "]"); }
                else                                     { println("fail: comando invalido"); }
            } catch (ExtractException e) {
                println(e.getMessage());
                // println(e.getLabels());
            } catch (Exception e) {
                println(e.getMessage());
            }
        }
    }

    private static Scanner scanner = new Scanner(System.in);
    private static String  input()                { return scanner.nextLine();        }
    private static double  number(String value)   { return Double.parseDouble(value); }
    public  static void    println(Object value)  { System.out.println(value);        }
    public  static void    print(Object value)    { System.out.print(value);          }
}
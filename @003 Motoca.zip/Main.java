// 1. Fiz tudo sozinho e consegui entender a questao e usar o que o professor passou em sala.
//fiz tudo mas nao tava entendendo como fazer o metodo drive, dai pedi o chatgpt que criasse uma logica parecida e fui modificando para java e deu certo, fiquei confuso nos metodos em ingles 
//por isso ate demorei pegar a logica dessa questao.
// 3. entendi o inicio de java pra objetos ate que bem, to estudando pra aprender a logica de organizar as informacoes
// 4. levei o tempo da aula e em casa em torno de 4h pra refazer e entender os conteudos.
import java.util.*;

class Person {
    private String name;
    private int age;
    public Person(String name, int age){
        this.name=name;
        this.age=age;
       // this.power=power;
    }
    public String getName() {
        return name;
    }
    public int getAge() {
        return age;
    }
     public String toString() {
        return name + ":" + age;
    }
        
    
}

class Motorcycle {
    private Person person; //agregacao
    private int power;
    private int time;
    
    //Inicia o atributo power, time com zero e person com null
    public Motorcycle(int power){
        this.power=power;
    }
    public int getPower() {
        return power;
    }
    public int getTime() {
        return time;
    }
    public Person getPerson() {
        return person;
    }
                                //Comprar mais tempo
    public void buy(int time){ 
        this.time+=time;
    }
    
    public boolean enter(Person person) {  //subir na moto
    if (this.person == null) {
        this.person = person;
        return true;
    } else {
        System.out.println("fail: busy motorcycle");
       return false; 
    }
}

   public Person leave() {     //checa se tem alguem.
    if (person != null) {
        Person tempPerson = person;
        person = null;
        return tempPerson;
    } else {
        System.out.println("fail: empty motorcycle");  //motocicleta vazia
        return null;
    }
}

    
        
    

public String toString() { //operador ternario ? o que vem antes é a condicao e depois 
//os valores verdade ou falso, como se fosse p if else
    String personInfo = (person != null) ? "(" + person.toString() + ")" : "(empty)";
    return "power:" + power + ", time:" + time + ", person:" + personInfo;
}



  public void drive(int time) {
    if (this.time >= time) {
        if (person != null) {
            if (person.getAge() <= 10) {
                this.time -= time;
               
            } else {
               
                System.out.println("fail: too old to drive");
            }
        } else {
            System.out.println("fail: empty motorcycle");
        }
    }else if(person!=null){
       if (this.time >= time) {
            this.time -= time;
        } else {
            System.out.println("fail: time finished after " + this.time + " minutes");
            this.time = 0;
        }
    }else {
        System.out.println("fail: buy time first");
    }
}

/*
public void drive(int time) {
    if (person != null) {
        if (this.time >= time) {
            this.time -= time;
         
        } else {
            System.out.println("fail: time finished after " + this.time + " minutes");
            this.time = 0;
        }
    } else {
        System.out.println("fail: empty motorcycle");
    }
}

*/
                                //buzinar
    public void honk(){  
        System.out.print("P");
    for (int i = 0; i < power; i++) {
        System.out.print("e");
    }
    System.out.println("m");  
    }
    
    
}
class Main{
    static Motorcycle motoca = new Motorcycle(1);

    public static void main(String[] args) {    
        while(true) {
            String line = input();
            args = line.split(" ");
            write('$' + line);

            if      (args[0].equals("show"))     { System.out.println(motoca);                         }
            else if (args[0].equals("init"))     { motoca = new Motorcycle(number(args[1]));           }  
            else if (args[0].equals("buy"))      { motoca.buy(number(args[1]));                        }
            else if (args[0].equals("drive"))    { motoca.drive(number(args[1]));                      }
            else if (args[0].equals("enter"))    { motoca.enter(new Person(args[1], number(args[2]))); }
            else if (args[0].equals("honk"))     { motoca.honk();                                      }
            else if (args[0].equals("leave"))    {
                Person person = motoca.leave();
                if(person != null) {
                    System.out.println(person.toString());
                }
            }
            else if (args[0].equals("end"))      { break;                                              }
            else
                System.out.println("fail: comando invalido");
        }
        scanner.close();
    }

    static Scanner scanner = new Scanner(System.in);

    public static String input()           { return scanner.nextLine();    }
    public static void write(String value) { System.out.println(value);    }
    public static int number(String str)   { return Integer.parseInt(str); }
}


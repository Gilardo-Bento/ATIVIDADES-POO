// 1. Fiz tudo e consegui entender bem esses conceitos iniciais, mas ainda fiquei na duvida na parte do metod carregar a bateria, vi uns videos e perguntei aos colegas como funcionava direito.
// 2. Fiz sozinho, mas nao estava passando em todos os testes, dai durante a aula o MARCOS VINICIUS E O GUILHERME me ajudaram a identificar o erro(no THIS).
// 3. entendi a questao e consegui acompanhar o raciocinio dela, mas preciso ainda abstrair os conceitos de POO
// 4. levei o tempo da aula e em casa em torno de 2h pra refazer e entender os conteudos.
import java.util.*;


class Calculator {
    public int batteryMax;
    public int battery;
    public float display;

    public Calculator(int batteryMax) {
        this.batteryMax = batteryMax;
        this.battery = 0;
        this.display = 0.0f;
    }

    public void chargeBattery(int value) {
        if (value < 0)
            return;
        this.battery += value;
        if (this.battery > this.batteryMax)
            this.battery = this.batteryMax;
    }

    public boolean useBattery() {
        if (this.battery == 0) {
            System.out.println("fail: bateria insuficiente");
            return false;
        }
        this.battery -= 1;
        return true;
    }

    public void sum(int a, int b) {
        if (useBattery())
            this.display = (a + b);
    }

    public void division(int num, int den) {
        if (!useBattery())
            return;
        if (den == 0) {
            System.out.println("fail: divisao por zero");
        } else
            this.display = (float) num / den;
    }

    public String toString() {
        return String.format("display = %.2f, battery = %d", this.display, this.battery);

        // se seu java estiver utilizando `,` como separador decimal, use:
        // DecimalFormat df = new DecimalFormat("0.00");
        // return String.format("display = %s, battery = %d", df.format(this.display), this.battery);
    }
}



public class result {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Calculator calc = new Calculator(0);

        while (true) {
            String cmd = scanner.next();

            System.out.print("$"+cmd);
            if (cmd.equals("end")) {
                System.out.println();
                break;
            } else if (cmd.equals("init")) {
                int param = scanner.nextInt();
                System.out.println(" "+param);
                calc = new Calculator( param );
            } else if (cmd.equals("show")) {
                System.out.println();
                System.out.println( calc );
            } else if (cmd.equals("charge")) {
                int param = scanner.nextInt();
                System.out.println(" "+param);
                calc.chargeBattery( param );
            } else if (cmd.equals("sum")) {
                int param1 = scanner.nextInt();
                int param2 = scanner.nextInt();
                System.out.println(" "+param1+" "+param2);
                calc.sum( param1, param2 );
            } else if (cmd.equals("div")) {
                int param1 = scanner.nextInt();
                int param2 = scanner.nextInt();
                System.out.println(" "+param1+" "+param2);
                calc.division( param1, param2 );
            }
        }
        scanner.close();
    }
}




// public class Main {
//     public static void main(String[] a) {
//         Calculator calc = new Calculator(0);
        
//         while (true) {
//             var line = input();
//             write("$" + line);
//             var args = line.split(" ");

//             if      (args[0].equals("end"))        { break;                                }
//             else if (args[0].equals("init"))       { calc = new Calculator( (int) number(args[1]) );              }
//             else if (args[0].equals("show"))       { System.out.println(calc);              }
//             else if (args[0].equals("charge"))     { calc.chargeBattery( (int) number(args[1]) );                          }
//             else if (args[0].equals("sum"))        { calc.sum((int) number(args[1]),(int) number(args[2]));     }
//             else if (args[0].equals("div"))        { calc.division((int) number(args[1]),(int) number(args[2]));      }
//             else                                   { write("fail: comando invalido");}
//         }
//     }

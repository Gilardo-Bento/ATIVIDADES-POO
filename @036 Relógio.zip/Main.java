// 1. Fiz tudo e consegui entender bem esses conceitos iniciais, so nos metodos que complicou mais um pouco, mas pesquisei como impementar metodos e deu certo.
// 2. Fiz junto com o senhor durante a aula e em casa tentei refazer e consegui, mas eu peguei todos os conceitos.
// 3. entendi o inicio de java pra objetos ate que bem, to estudando pra aprender a logica de organizar as informacoes
// 4. levei o tempo da aula e em casa em torno de 3h pra refazer e entender os conteudos.
//5. demorei muito a compilar corretamente pq sempre tava com dificuldade na sintaxe ainda, mas em casa fui pesquisando como se usa em java.
import java.util.*;

class Tempo {
    private int hr   = 0;
    private int min = 0;
    private int seg = 0;

    public Tempo(int hr, int min, int seg) {
        this.setHr(hr);
        this.setMin(min);
        this.setSeg(seg);
    }

    public void setHr(int hr) {
        if (hr < 0 || hr > 23) {
            System.out.println("fail: hora invalida");
        } else {
            this.hr = hr;
        }
    }
    public void setMin(int min) {
        if (min < 0 || min > 59) {
            System.out.println("fail: minuto invalido");
        } else {
            this.min = min;
        }
    }
    public void setSeg(int seg) {
        if (seg < 0 || seg > 59) {
            System.out.println("fail: segundo invalido");
        } else {
            this.seg = seg;
        }
    }
    public int getHr() {
        return hr;
    }
    public int getMin() {
        return min;
    }
    public int getSeg() {
        return seg;
    }
    public void nextSeg() {
        seg++;
        if (seg > 59) {
            seg = 0;
            min++;
            if (min > 59) {
                min = 0;
                hr++;
                if (hr > 23) {
                    hr = 0;
                }
            }
        }
    }
    public String toString() {
        return String.format("%02d:%02d:%02d", hr, min, seg);
    }
}

public class Main {
    public static void main(String[] a) {
        Tempo tempo = new Tempo(0, 0, 0);
        
        while (true) {
            var line = input();
            write("$" + line);
            var args = line.split(" ");

            if      (args[0].equals("end"))   { 
                break; 
            }
            else if (args[0].equals("show"))  { 
                System.out.println(tempo); 
            }
            else if (args[0].equals("next"))  { 
                tempo.nextSeg(); 
            }
            else if (args[0].equals("set")) {
                tempo.setHr((int)number(args[1]));
                tempo.setMin((int)number(args[2]));
                tempo.setSeg((int)number(args[3]));
            }
            else if (args[0].equals("init")) {
                tempo = new Tempo((int)number(args[1]), (int)number(args[2]), (int)number(args[3]));
            }
            else { 
                write("fail: comando invalido"); 
            }
        }
    }

    private static Scanner scanner = new Scanner(System.in);
    private static String  input()              { return scanner.nextLine(); }
    private static double  number(String value) { return Double.parseDouble(value); }
    private static void    write(String value)  { System.out.println(value); }
}
import java.util.*;

class Cliente {
    private String id;
    private String fone;

    public Cliente(String id, String fone) {
        this.id = id;
        this.fone = fone;
    }

    @Override
    public String toString() {
        return id + ":" + fone;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFone() {
        return this.fone;
    }

    public void setFone(String fone) {
        this.fone = fone;
    }
}

class Sala {
    private List<Cliente> cadeiras;

    public Sala(int capacidade) {
        cadeiras = new ArrayList<>(capacidade);
        for (int i = 0; i < capacidade; i++) {
            cadeiras.add(null);
        }
    }

    public List<Cliente> getCadeiras() {
        return cadeiras;
    }

  public boolean reservar(String id, String fone, int ind) {
    if (ind >= 0 && ind < cadeiras.size()) {
        if (cadeiras.get(ind) == null) {
            // Verifica se o cliente já está no cinema
            for (Cliente cliente : cadeiras) {
                if (cliente != null && cliente.getId().equals(id)) {
                    System.out.println("fail: cliente ja esta no cinema");
                    return false;
                }
            }
            // Se o cliente não estiver no cinema, reserve a cadeira
            Cliente cliente = new Cliente(id, fone);
            cadeiras.set(ind, cliente);
            return true;
        } else {
            System.out.println("fail: cadeira ja esta ocupada");
        }
    } else {
        System.out.println("fail: cadeira nao existe");
    }
    return false;
}


    public void cancelar(String id) {
        for (int i = 0; i < cadeiras.size(); i++) {
            Cliente cliente = cadeiras.get(i);
            
            //verificar se existe o cliente para que possa cancelar.
           
            if (cliente != null && cliente.getId().equals(id)) {
                cadeiras.set(i, null);
                break;
            }else{
            System.out.println("fail: cliente nao esta no cinema");
            return;
        } 
    }
}
    @Override
 public String toString() {
    StringBuilder saida = new StringBuilder("[");
    boolean primeiro=true;
    for (Cliente cliente : cadeiras) {
        if (primeiro) {
            primeiro = false;
        } else {
            saida.append(" ");
        }
        if (cliente == null) {
            saida.append("-");
        } else {
            saida.append(cliente);
        }
    }
    saida.append("]");
    return saida.toString();
}


}

class Solver {
    static Shell sh = new Shell();
    static Sala sala = new Sala(0);

    public static void main(String args[]) {
        sh.chain.put("init", () -> {
            sala = new Sala(getInt(1));
        });
        sh.chain.put("show",() -> {
            System.out.println(sala);
        });
        sh.chain.put("reservar", () -> {
            if (sala.reservar(getStr(1), getStr(2), getInt(3))) {
            } else {
            }
        });
        sh.chain.put("cancelar", () -> {
            sala.cancelar(getStr(1));
        });

        sh.execute();
    }

    static int getInt(int pos) {
        return Integer.parseInt(sh.param.get(pos));
    }

    static String getStr(int pos) {
        return sh.param.get(pos);
    }
}



    class Shell {
        public Scanner scanner = new Scanner(System.in);
        public HashMap<String, Runnable> chain = new HashMap<>();
        public ArrayList<String> param = new ArrayList<>();
    
        public Shell() {
            Locale.setDefault(new Locale("en", "US"));
        }
    
        public void execute() {
        while (true) {
            param.clear();
            String line = scanner.nextLine();
            Collections.addAll(param, line.split(" "));
            System.out.println("$" + line);
            if (param.get(0).equals("end")) {
                break;
            } else if (chain.containsKey(param.get(0))) {
                chain.get(param.get(0)).run();
            } else {
                System.out.println("fail: comando invalido");
            }
        }
    }
}

// 1. Essa questao nao consegui fazer direito sozinho professor, precisei ir acompanhado a que foi feita em sala, fiquei confuso e tive que consultar a resolucao
//fiz tudo mas nao tava entendendo os enum de fato, assisti algumas aulas para pegar o conceito.
//por isso ate demorei pegar a logica dessa questao.
// 3. entendi o inicio ate bem mas depois fiquei confuso ainda , to estudando pra aprender a logica de organizar as informacoes
// 4. levei o tempo da aula e em casa em torno de 5h pra refazer e buscar entender os conteudos novos repassados.
import java.util.*;
enum Label {
    GIVE,
    TAKE,
    PLUS;
    
    @Override
    public String toString() {
        return this.name().toLowerCase(); //coverte em Maiusculas
        //toLowerCase() em Miniscula.
    }
}

class Operation {
    private static int nextOpId = 0;
    private int id;
    private String name;
    private Label label;
    private int value;

    public Operation( String name, Label label, int value ) {
        this.id = Operation.nextOpId++;
    
        this.name = name;
        this.label = label;
        this.value = value;
    }
    
    @Override
    public String toString() {
        return "id:" + this.id + " " + this.label + ":" + this.name + " " + this.value;
    }

    public int getId() {
        return this.id;
    }
    public String getName() {
        return this.name;
    }
    public Label getLabel() {
        return this.label;
    }
    public int getValue() {
        return this.value;
    }
}

class Client {
    private String name;
    private int limite;
    ArrayList<Operation> operations;

    public Client(String name, int limite) {
        this.name = name;
        this.limite = limite;
        this.operations = new ArrayList<Operation>();
    }
    @Override
    public String toString() {
        String ss = this.name + " " + this.getBalance() + "/" + this.limite + "\n";
        for ( Operation oper : this.operations ) {
            ss += oper + "\n";
        }
        return ss;
    }

    public String getName() {
        return this.name;
    }
    public int getLimite() {
        return this.limite;
    }
    public ArrayList<Operation> getOperations() {
        return this.operations;
    }

    public void addOperation(Operation operation) {
        this.operations.add( operation );
    }
    //quanto esta devendo
    public int getBalance() {
        int balance = 0;
        for ( Operation oper : this.operations ) {
            if ( oper.getLabel() == Label.TAKE ) {
                balance -= oper.getValue();
            } else {
                balance += oper.getValue();
            }
        }
        return balance;
    }
}





class ClienteInvalidoException extends Exception {
    @Override
    public String getMessage() {
        return "fail: cliente nao existe";
    }
}

class ClienteException extends Exception {
    private boolean existe;
    
    public ClienteException(boolean existe) {
        this.existe = existe;
    }
    
    @Override
    public String getMessage() {
        if (this.existe)
            return "fail: cliente ja existe";
        else
            return "fail: cliente nao existe";
    }
}



class Agiota {
    private ArrayList<Client> aliveList;
    private ArrayList<Client> deathList;
    private ArrayList<Operation> aliveOper;
    private ArrayList<Operation> deathOper;

    private int searchClient(String name) {
        for (int i=0; i<this.aliveList.size(); i++) {
            if ( this.aliveList.get(i).getName().equals(name) ) {
                return i;
            }
        }
        return -1;
    }
    private void pushOperation(Client client, String name, Label label, int value) {
        Operation oper = new Operation( name, label, value );
        this.aliveOper.add( oper );
        client.addOperation( oper );
    }




    private void sortAliveList() {
        

        this.aliveList.sort(
            new Comparator<Client>() {
                public int compare(Client c1, Client c2) {
                    return c1.getName().compareTo( c2.getName() );
                }
            }
        );

        
    }

    public Agiota() {
        this.aliveList = new ArrayList<Client>();
        this.deathList = new ArrayList<Client>();
        this.aliveOper = new ArrayList<Operation>();
        this.deathOper = new ArrayList<Operation>();
    }

    public Client getClient(String name) {
        int ind = this.searchClient(name);

        if (ind == -1) {
            return null;
        }

        return this.aliveList.get(ind);
    }

    public void addClient(String name, int limite) throws Exception {
        Client client = getClient(name);

        if (client != null) {
            // Solver.println("fail: cliente ja existe");
            // return;
            // throw new Exception("fail: cliente ja existe");
            throw new ClienteException(true);
        }

        this.aliveList.add( new Client(name,limite) );
        
        this.sortAliveList();
    }

    public void give(String name, int value) throws Exception {     //Emprestar
        Client client = getClient(name);

        if (client == null) {
           
            throw new ClienteException(false);
        }

        if (client.getBalance() + value > client.getLimite()) {
            
            throw new Exception("fail: limite excedido");
        }

        this.pushOperation( client, name, Label.GIVE, value );
    }

    public void take(String name, int value) throws Exception {     //pegar
        Client client = getClient(name);

        if (client == null) {
            
            throw new ClienteException(false);
        }

        this.pushOperation( client, name, Label.TAKE, value );
    }

    public void kill(String name) {             //Matar
        int ind = this.searchClient(name);

        if (ind == -1) {
            return;
        }

        this.deathList.add( this.aliveList.remove(ind) );

     
        for (int i=0; i<this.aliveOper.size(); i++) {
            if ( this.aliveOper.get(i).getName().equals(name) ) {
                this.deathOper.add( this.aliveOper.remove(i) );
                i--;
            }
        }
    }

    public void plus() {
        for (Client client : this.aliveList) {
            this.pushOperation( client, client.getName(), Label.PLUS, (int) Math.ceil( 0.1*client.getBalance() ) );
        }
      
        for (int i=0; i<this.aliveList.size(); i++) {
            Client client = this.aliveList.get(i);
            if ( client.getBalance() > client.getLimite() ) {
                this.kill( client.getName() );
                i--;
            }
        }
    }

    @Override
    public String toString() {
        String ss = "";
        for ( Client client : this.aliveList ) {
            ss += ":) " + client.getName() + " " + client.getBalance() + "/" + client.getLimite() + "\n";
        }
        for ( Operation oper : this.aliveOper ) {
            ss += "+ " + oper + "\n";
        }
        for ( Client client : this.deathList ) {
            ss += ":( " + client.getName() + " " + client.getBalance() + "/" + client.getLimite() + "\n";
        }
        for ( Operation oper : this.deathOper ) {
            ss += "- " + oper + "\n";
        }
        return ss;
    }
}

public class Solver {
    public static void main(String[] arg) {
        println("side_by_side=080");
        
        Agiota agiota = new Agiota();

        while (true) {
            String line = input();
            println("$" + line);
            String[] args = line.split(" ");

            try {
                if      (args[0].equals("end"))     { break; }
                else if (args[0].equals("init"))    { agiota = new Agiota(); }
                else if (args[0].equals("show"))    { print(agiota); }
                else if (args[0].equals("showCli")) { print( agiota.getClient( args[1] ) ); }
                else if (args[0].equals("addCli"))  { agiota.addClient( args[1], (int) number(args[2]) ); }
                else if (args[0].equals("give"))    { agiota.give( args[1], (int) number(args[2]) ); }
                else if (args[0].equals("take"))    { agiota.take( args[1], (int) number(args[2]) ); }
                else if (args[0].equals("kill"))    { agiota.kill( args[1] ); }
                else if (args[0].equals("plus"))    { agiota.plus(); }
                else                                { println("fail: comando invalido"); }
            
            } catch (Exception e) {
                println(e.getMessage());
            }
        }
    }

    private static Scanner scanner = new Scanner(System.in);
    private static String  input()                { return scanner.nextLine();        }
    private static double  number(String value)   { return Double.parseDouble(value); }
    public  static void    println(Object value)  { System.out.println(value);        }
    public  static void    print(Object value)    { System.out.print(value);          }
}
/*
import java.util.*;
enum Label {
    DAR,
    PEGAR,
    MAIS;

    @Override
    public String toString() {
        return this.name().toLowerCase(); // converte em minúsculas
    }
}

class Operacao {
    private static int proximoIdOp = 0;
    private int id;
    private String nome;
    private Label etiqueta;
    private int valor;

    public Operacao(String nome, Label etiqueta, int valor) {
        this.id = Operacao.proximoIdOp++;

        this.nome = nome;
        this.etiqueta = etiqueta;
        this.valor = valor;
    }

    @Override
    public String toString() {
        return "id:" + this.id + " " + this.etiqueta + ":" + this.nome + " " + this.valor;
    }

    public int getId() {
        return this.id;
    }
    public String getNome() {
        return this.nome;
    }
    public Label getEtiqueta() {
        return this.etiqueta;
    }
    public int getValor() {
        return this.valor;
    }
}

class Cliente {
    private String nome;
    private int limite;
    ArrayList<Operacao> operacoes;

    public Cliente(String nome, int limite) {
        this.nome = nome;
        this.limite = limite;
        this.operacoes = new ArrayList<Operacao>();
    }
    @Override
    public String toString() {
        String ss = this.nome + " " + this.getSaldo() + "/" + this.limite + "\n";
        for (Operacao oper : this.operacoes) {
            ss += oper + "\n";
        }
        return ss;
    }

    public String getNome() {
        return this.nome;
    }
    public int getLimite() {
        return this.limite;
    }
    public ArrayList<Operacao> getOperacoes() {
        return this.operacoes;
    }

    public void adicionarOperacao(Operacao operacao) {
        this.operacoes.add(operacao);
    }
    // quanto está devendo
    public int getSaldo() {
        int saldo = 0;
        for (Operacao oper : this.operacoes) {
            if (oper.getEtiqueta() == Label.PEGAR) {
                saldo -= oper.getValor();
            } else {
                saldo += oper.getValor();
            }
        }
        return saldo;
    }
}

class ClienteInvalidoException extends Exception {
    @Override
    public String getMessage() {
        return "falha: cliente não existe";
    }
}

class ClienteException extends Exception {
    private boolean existe;

    public ClienteException(boolean existe) {
        this.existe = existe;
    }

    @Override
    public String getMessage() {
        if (this.existe)
            return "falha: cliente já existe";
        else
            return "falha: cliente não existe";
    }
}

class Agiota {
    private ArrayList<Cliente> listaAtivos;
    private ArrayList<Cliente> listaInativos;
    private ArrayList<Operacao> operacoesAtivas;
    private ArrayList<Operacao> operacoesInativas;

    private int procurarCliente(String nome) {
        for (int i = 0; i < this.listaAtivos.size(); i++) {
            if (this.listaAtivos.get(i).getNome().equals(nome)) {
                return i;
            }
        }
        return -1;
    }

    private void adicionarOperacao(Cliente cliente, String nome, Label etiqueta, int valor) {
        Operacao oper = new Operacao(nome, etiqueta, valor);
        this.operacoesAtivas.add(oper);
        cliente.adicionarOperacao(oper);
    }

    private void ordenarListaAtivos() {
        this.listaAtivos.sort(
                new Comparator<Cliente>() {
                    public int compare(Cliente c1, Cliente c2) {
                        return c1.getNome().compareTo(c2.getNome());
                    }
                }
        );
    }

    public Agiota() {
        this.listaAtivos = new ArrayList<Cliente>();
        this.listaInativos = new ArrayList<Cliente>();
        this.operacoesAtivas = new ArrayList<Operacao>();
        this.operacoesInativas = new ArrayList<Operacao>();
    }

    public Cliente obterCliente(String nome) {
        int ind = this.procurarCliente(nome);

        if (ind == -1) {
            return null;
        }

        return this.listaAtivos.get(ind);
    }

    public void adicionarCliente(String nome, int limite) throws Exception {
        Cliente cliente = obterCliente(nome);

        if (cliente != null) {
            throw new ClienteException(true);
        }

        this.listaAtivos.add(new Cliente(nome, limite));

        this.ordenarListaAtivos();
    }

    public void dar(String nome, int valor) throws Exception {
        Cliente cliente = obterCliente(nome);

        if (cliente == null) {
            throw new ClienteException(false);
        }

        if (cliente.getSaldo() + valor > cliente.getLimite()) {
            throw new Exception("falha: limite excedido");
        }

        this.adicionarOperacao(cliente, nome, Label.DAR, valor);
    }

    public void pegar(String nome, int valor) throws Exception {
        Cliente cliente = obterCliente(nome);

        if (cliente == null) {
            throw new ClienteException(false);
        }

        this.adicionarOperacao(cliente, nome, Label.PEGAR, valor);
    }

    public void matar(String nome) {
        int ind = this.procurarCliente(nome);

        if (ind == -1) {
            return;
        }

        this.listaInativos.add(this.listaAtivos.remove(ind));

        for (int i = 0; i < this.operacoesAtivas.size(); i++) {
            if (this.operacoesAtivas.get(i).getNome().equals(nome)) {
                this.operacoesInativas.add(this.operacoesAtivas.remove(i));
                i--;
            }
        }
    }

    public void mais() {
        for (Cliente cliente : this.listaAtivos) {
            this.adicionarOperacao(cliente, cliente.getNome(), Label.MAIS, (int) Math.ceil(0.1 * cliente.getSaldo()));
        }

        for (int i = 0; i < this.listaAtivos.size(); i++) {
            Cliente cliente = this.listaAtivos.get(i);
            if (cliente.getSaldo() > cliente.getLimite()) {
                this.matar(cliente.getNome());
                i--;
            }
        }
    }

    @Override
    public String toString() {
        String ss = "";
        for (Cliente cliente : this.listaAtivos) {
            ss += ":) " + cliente.getNome() + " " + cliente.getSaldo() + "/" + cliente.getLimite() + "\n";
        }
        for (Operacao oper : this.operacoesAtivas) {
            ss += "+ " + oper + "\n";
        }
        for (Cliente cliente : this.listaInativos) {
            ss += ":( " + cliente.getNome() + " " + cliente.getSaldo() + "/" + cliente.getLimite() + "\n";
        }
        for (

*/



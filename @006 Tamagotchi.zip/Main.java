// 1. Fiz tudo e consegui entender bem esses conceitos, maas tive uma dificuldade em entender o THIS.
// 2. Fiz junto com o senhor durante a aula e quando fiz sozinho nao tava passando em  todos os testes
 // e o MARCOS VINICIUS E O GUILHERME ME ajudaram e em casa tentei refazer e consegui, mas eu peguei todos os conceitos.
// 3. entendi o inicio de java pra objetos ate que bem, to estudando pra aprender a logica de organizar as informacoes
// 4. levei o tempo da aula e em casa em torno de 2h pra refazer e entender os conteudos.
import java.util.*;

class Pet{
    private int energyMax, hungryMax, cleanMax;
    private int energy, hungry, clean;
    private int diamonds;
    private int age;
    private boolean alive;

    public Pet(int energy, int hungry, int clean){
        this.energyMax= energy;
        this.hungryMax= hungry;
        this.cleanMax= clean;
        
        this.energy= energy;
        this.hungry= hungry;
        this.clean= clean;
        
        this.diamonds=0;
        this.age=0;
        this.alive= true;
    }

    void setEnergy(int value){
        if(value <= 0){
            this.energy = 0;
            System.out.println("fail: pet morreu de fraqueza");
            this.alive = false;
            return;
        } 
       else if(value > this.energyMax) {
            this.energy = this.energyMax;
            return;
        }
      else {
          this.energy = value;
    }
  }

    public void setHungry(int value){
        if(value<=0){
            this.hungry=0;
            System.out.println("fail: pet morreu de fome");
            this.alive=false;
        }else if(value> this.hungryMax){
            this.hungry= this.hungryMax;
        }else{
            this.hungry = value;
        }
    }
    
    void setClean(int value){
        if(value<=0){
          this.clean=0;
          this.alive=false;
       System.out.println("fail: pet morreu de sujeira");

        }else if (value> this.cleanMax){
            this.clean=this.cleanMax;
        } else{
            this.clean= value;
        }
    }

   


  public String toString(){
        String ss = "";
        ss +=  "E:" + this.energy + "/" + this.energyMax + ", "
            +  "S:" + this.hungry + "/" + this.hungryMax + ", "
            +  "L:" + this.clean + "/" + this.cleanMax + ", "
            +  "D:" + this.diamonds + ", " + "I:"  + this.age;
           
        return ss;
    }
    private boolean testAlive(){
         if(this.alive){
            return true;
         } else { 
             
             System.out.println("fail: pet esta morto");
                return false;
         }      
    
    }
    public void play(){   //BRINCAR
        if(!testAlive()){
            return;
        }
        setEnergy(getEnergy() - 2);
        setHungry(getHungry() - 1);
        setClean(getClean() - 3);
        this.diamonds += 1;
        this.age += 1;
    }
    
    public void shower(){ //BANHAR
        if(!testAlive()){
            return;
        }
        setEnergy(this.energy - 3);
        setHungry(this.hungry - 1);
        setClean(getCleanMax());
        this.age += 2;
    
    }

    public void eat(){  //COMER
        if(!testAlive()){
            return;
        }
        setEnergy(getEnergy() - 1);
        setHungry(getHungry() + 4);
        setClean(getClean() - 2);
        this.age += 1;
    }
    
    public void sleep(){  //DORMIR
        if(!testAlive())
            return;
        if(this.energyMax - this.energy<5){
         System.out.println("fail: nao esta com sono");
          
          return; 
        }
        this.age += this.energyMax- this.energy;
        this.setEnergy(this.energyMax);
        this.setHungry(this.hungry-1);
    }


    int getClean(){
        return clean;
    }
    int getHungry(){
        return hungry;
    }
    int getEnergy(){
        return energy;
    }
    int getEnergyMax(){
        return energyMax;
    }
    int getCleanMax(){
        return cleanMax;
    }
    int getHungryMax(){
        return hungryMax;
    }
}


public class Main {
    public static void main(String[] a) {
        Pet pet = new Pet(0, 0, 0);
        
        while (true) {
            var line = input();
            write("$" + line);
            var args = line.split(" ");

            if      (args[0].equals("end"))   { break;                                                                           }
            else if (args[0].equals("show"))  { write(pet.toString());                                                           }
            else if (args[0].equals("init"))  { pet = new Pet((int)number(args[1]), (int)number(args[2]), (int)number(args[3])); }
            else if (args[0].equals("play"))  { pet.play();                                                                      }
            else if (args[0].equals("eat"))   { pet.eat();                                                                       }
            else if (args[0].equals("sleep")) { pet.sleep();                                                                     }
            else if (args[0].equals("shower")){ pet.shower();                                                                    }
            else                              { write("fail: comando invalido");                                                 }
        }
    }

    private static Scanner scanner = new Scanner(System.in);
    private static String  input()              { return scanner.nextLine(); }
    private static double  number(String value) { return Double.parseDouble(value); }
    private static void    write(String value)  { System.out.println(value); }
}







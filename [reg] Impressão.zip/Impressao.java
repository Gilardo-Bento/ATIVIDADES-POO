// 1. Fiz tudo e consegui entender bem esses conceitos iniciais, consegui acompanhar na aula.
// 2. Fiz junto com o senhor durante a aula e em casa tentei refazer e consegui, mas eu peguei todos os conceitos.
// 3. entendi o inicio de java pra objetos ate que bem, to estudando pra aprender a logica de organizar as informacoes
// 4. levei o tempo da aula e em casa em torno de 1h pra refazer e entender os conteudos.
            import java.util.Scanner;
            
            class Aluno {
                String nome;
                int matr;
                String disc;
                float nota;
            
                void ler() {
                    nome = input();
                    matr = Integer.parseInt( input() );
                    disc = input();
                    nota = Float.parseFloat( input() );
                }
                
                void imprimir() {
                    println("Nome = " + nome);
                    println("Matrícula = " + matr);
                    println("Disciplina = " + disc);
                    println("Nota = " + nota);
                }
                
                static Scanner in = new Scanner(System.in);
                String input() { return in.nextLine(); }
                void print(String str) { System.out.print( str ); }
                void println(String str) { System.out.println( str ); }
            }
            
            
            
            class Impressao {
                public static void main(String[] arg) {
                    Aluno a1 = new Aluno();
                    a1.ler();
                    a1.imprimir();
            }
            }
            
            
            
            
            
            
            
            
            // import java.util.Scanner;
            
            // class Aluno {
            //     String nome;
            //     int matr;
            //     String disc;
            //     float nota;
            
            //     void ler() {
            //         Scanner in = new Scanner(System.in);
                    
            //         nome = in.nextLine();
            //         matr = Integer.parseInt( in.nextLine() );
            //         disc = in.nextLine();
            //         nota = Float.parseFloat( in.nextLine() );
            //     }
                
            //     void imprimir() {
            //         System.out.println("Nome = " + nome);
            //         System.out.println("Matrícula = " + matr);
            //         System.out.println("Disciplina = " + disc);
            //         System.out.println("Nota = " + nota);
            //     }
            // }
            
            
            
            // class Impressao {
            //     public static void main(String[] arg) {
            //         Aluno a1 = new Aluno();
            
            //         a1.ler();
            
            //         a1.imprimir();
            
            //     }
            // }
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            // import java.util.Scanner;
            
            // class Impressao {
            //     public static void main(String[] arg) {
            //         Scanner in = new Scanner(System.in);
                    
            //         String nome = in.nextLine();
            //         int matr = Integer.parseInt( in.nextLine() );
            //         String disc = in.nextLine();
            //         float nota = Float.parseFloat( in.nextLine() );
                    
            //         System.out.println("Nome = " + nome);
            //         System.out.println("Matrícula = " + matr);
            //         System.out.println("Disciplina = " + disc);
            //         System.out.println("Nota = " + nota);
            //     }
            // }
            
            
            
            
            
            
            
            
            

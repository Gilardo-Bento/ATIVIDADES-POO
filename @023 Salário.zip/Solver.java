//professor demorei um pouco pra terminar, durante a aula nao consegui, ate o senhor viu meu codigo e me explicou sobre o Super. E sobre as classes filhas que herdam da classe Pai,
//com isso consegui entender como funcionava a questao do salario que pra cada um funcionario eu tive que tratar especificamente.
import java.util.*;
/*class MsgException extends RuntimeException{
    public MsgException(String message){
        super(message);
    }
}*/

class UFC{
    private Map<String, Funcionario> funcionarios= new TreeMap<>();
    //public Funcionario getFuncionario(String nome){
      //  super();
    
    public  void addFuncionario(Funcionario funcionario){
        funcionarios.put(funcionario.getNome(), funcionario);
        
    }
    public void rmFuncionario( String nome){
        if(funcionarios.containsKey(nome)){
            funcionarios.remove(nome);
        }
    }
    public void setBonus (int bonus){
        int bonusIND = bonus/funcionarios.size();
        for(Funcionario funcionario : funcionarios.values()){
            funcionario.setBonus(bonusIND);
        }
        
    }
    public Funcionario getFuncionario(String nome) throws Exception{
        return funcionarios.get(nome);
    }
    @Override
    public String toString(){
        int i=0;
        int size= this.funcionarios.size();
        String s= "";
        //StringBuilder result =new StringBuilder();
        for (Funcionario funcionario : this.funcionarios.values()){
            s += funcionario;
            if(i<size- 1){
                s+= ("\n");
            }
            i++;
        }
        return s;
    }
}

abstract class Funcionario {
    protected String nome;
    protected int bonus;
    protected int diarias;
    protected int maxDiarias;
    
    public Funcionario(String nome){
        this.nome= nome;
    }
    
    public  String getNome(){
        return this.nome;    
    }
    public  int setBonus(int bonus){
        return this.bonus = bonus;
    }
    public void addDiaria() throws Exception {
        if(diarias < maxDiarias){
            diarias++;
        }else{
            throw new Exception ("fail: limite de diarias atingido");
        }
    }
    public int getSalario(){
        return bonus + diarias * 100;   
    }
    @Override
    public  String toString(){
        return "prof:"+ nome + ":" + maxDiarias ;
    }
}

class Professor extends Funcionario{
    protected String classe;
    protected int salario=super.getSalario();
    public Professor(String nome, String classe){
        super(nome);
        // this.nome=nome;
        this.classe=classe;
        this.maxDiarias = 2;
    }
    public  String getClasse(){
        return this.classe;    
    }
    public  int getSalario(){
        if(classe.equals("A")){
            this.salario=3000;
        }else if(classe.equals("B")){
            this.salario=5000;
        }else if(classe.equals("C")){
            this.salario=7000;
        }else if(classe.equals("D")){
            this.salario=9000;
        }else if(classe.equals("E")){
            this.salario=11000;
        }
        return salario+diarias*100;
    }
    @Override
    public  String toString(){
        return "prof:"+ nome + ":" + classe + ":" +  getSalario();
    }
}
class STA extends Funcionario {
    protected int nivel;
    protected int salario;
    public STA(String nome, int nivel){
        super(nome);
        this.nivel= nivel;
        this.maxDiarias = 1;
    }
    public int getNivel(){
        return this.nivel;
    }
    @Override 
    public int getSalario(){
        return this.salario= 3000 + (300*nivel)+ bonus + diarias*100;
    }
    
    public String toString(){
        return "sta:"+ nome +":"+ nivel + ":" + getSalario();
    }
}

class Tercerizado extends Funcionario{
    protected int horas;
    protected String isSalubre;
    protected int salario;
    
    public Tercerizado (String nome, int horas, String isSalubre){
        super(nome);
        this.horas=horas;
        this.isSalubre=isSalubre;
        this.maxDiarias=0;
        
    }
    public int getHoras(){
        return this.horas;
    }
    public String getIsSalubre(){
        return isSalubre;
    }
    
     public int getSalario(){
         if(isSalubre.equals("sim")){
             this.salario=4*this.horas+500;
         }else{
             this.salario=4*this.horas;
         }
         return salario + bonus + diarias*100;
     }
     public void addDiaria() throws Exception {
            throw new Exception ("fail: terc nao pode receber diaria");
    }
    @Override
    public String toString(){
        return  "ter:" + nome + ":" + horas + ":" + getIsSalubre() + ":" + getSalario();
    }
}
class Solver{
    public static void main(String[] args){
        Scanner scanner = new Scanner (System.in);
        UFC ufc =new UFC();
        while(true){
            try{
                String line = scanner.nextLine();
                System.out.println("$" + line);
                String ui[] = line.split(" ");
                if(ui[0].equals("end")){
                    break;
                }else if(ui[0].equals("addProf")){
                    ufc.addFuncionario(new Professor(ui[1],ui[2]));
                }else if(ui[0].equals("addSta")){
                    ufc.addFuncionario(new STA(ui[1],Integer.parseInt(ui[2]) ));
                }else if(ui[0].equals("addTer")){
                    boolean isSalubre = Boolean.parseBoolean(ui[3]);
                    ufc.addFuncionario(new Tercerizado(ui[1],Integer.parseInt(ui[2]), ui[3]));
                }else if(ui[0].equals("rm")){
                    ufc.rmFuncionario(ui[1]);
                }else if(ui[0].equals("showAll")){
                    System.out.println(ufc);
                }else if(ui[0].equals("show")){
                    System.out.println(ufc.getFuncionario(ui[1]));
                }else if(ui[0].equals("addDiaria")){
                    ufc.getFuncionario(ui[1]).addDiaria();
                }else if(ui[0].equals("setBonus")){
                    ufc.setBonus(Integer.parseInt(ui[1]));
                }else{
                       System.out.print("");
                }
            }
            catch (Exception e){
                    System.out.println(e.getMessage());
            }
        }
        scanner.close();
    }
}

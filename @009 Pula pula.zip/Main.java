// 1. Essa questao nao consegui fazer direito sozinho professor, precisei ir acompanhado a que foi feita em sala, fiquei confuso e tive que consultar a resolucao
//fiz tudo mas nao tava entendendo os ArrayList de fato, assisti algumas aulas para pegar o conceito.
//por isso ate demorei pegar a logica dessa questao.
// 3. entendi o inicio de java pra objetos ate que bem, to estudando pra aprender a logica de organizar as informacoes
// 4. levei o tempo da aula e em casa em torno de 5h pra refazer e entender os conteudos.
import java.util.LinkedList;
import java.util.Scanner;
import java.util.stream.Collectors;



class Kid {
    private int age;
    private String name;

    public Kid(String name, int age) {
        this.name = name;
        this.age = age;
    }
    public int getAge() {
        return age;
    }
    public String getName() {
        return name;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String toString() {
        return name + ":" + age;
    }
}

class Trampoline{
    private LinkedList<Kid> waiting;
    private LinkedList<Kid> playing;
    
    public Trampoline() {
        waiting=new LinkedList<Kid>();
        playing=new LinkedList<Kid>();

    }

    private Kid removeFromList(String name, LinkedList<Kid> list) {
    for (int i = 0; i < list.size(); i++) {
        if (list.get(i).getName().equals(name)) {
            return list.remove(i);
        }
    }
    return null;
}


    public void arrive(Kid kid) {
        this.waiting.addFirst(kid);
    }

    public void enter() {
       Kid kid= this.waiting.removeLast();
        this.playing.addFirst(kid);
    }

    public void leave() {
        if ( !this.playing.isEmpty() ) {
            this.waiting.addFirst( this.playing.removeLast() );
        }
    }

    public Kid removeKid(String name) {
     Kid kid= this.removeFromList(name, this.waiting);
     if(kid==null){
               kid= this.removeFromList(name, this.playing);

     }
     return kid;
     
    }
    public String toString() {
        return   "[" + waiting.stream().map(Kid::toString).collect(Collectors.joining(", ")) + "]" + " => "
               + "[" + playing.stream().map(Kid::toString).collect(Collectors.joining(", ")) + "]";
    }
}


class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Trampoline tramp = new Trampoline();
        while(true) {
            String line = scanner.nextLine();
            System.out.println("$"+ line);
            String[] ui = line.split(" ");
            if(ui[0].equals("end")) {
                break;
            } else if(ui[0].equals("arrive")) { // name age
                tramp.arrive(new Kid(ui[1], Integer.parseInt(ui[2]))) ;
            } else if(ui[0].equals("enter")) {
                tramp.enter();
            } else if(ui[0].equals("leave")) {
                tramp.leave();
            } else if(ui[0].equals("remove")) {//name
                tramp.removeKid(ui[1]);
            } else if(ui[0].equals("show")) {
                System.out.println(tramp);
            } else {
                System.out.println("fail: comando invalido");
            }
        }
        scanner.close();
    }
}

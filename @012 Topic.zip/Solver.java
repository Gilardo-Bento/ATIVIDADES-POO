import java.util.*;
import java.util.stream.*;

class Passageiro {
    private String nome;
    private int idade;

    public Passageiro(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }
    
    public boolean isPrioridade() {
        return idade >= 65;
    }  
    
     
    public String getNome() {
        return this.nome;
    }
    
    public String toString(){
        return this.nome + ":" + this.idade;
    }

}

class Topic {
    private ArrayList<Passageiro> prioridadeAssento;
    private ArrayList<Passageiro> normalAssento;

    public Topic(int capacidade, int qtdPrioridade) {
        this.prioridadeAssento = new ArrayList<Passageiro>();
        for (int i=0; i < qtdPrioridade; i++) {
            this.prioridadeAssento.add( null );
        }

        this.normalAssento = new ArrayList<Passageiro>();
        for (int i=0; i<capacidade-qtdPrioridade; i++) {
            this.normalAssento.add( null );
        }  
    }  

    private static int primeiraPosicao(List<Passageiro> list) {
        for ( int i=0; i<list.size(); i++ ) {
            if ( list.get(i) == null ) {
                return i;
            }
        }
        return -1;
    }
    
    private static int encontrarPorNome(String nome, List<Passageiro> list) {
        for ( int i=0; i<list.size(); i++ ) {
            Passageiro p = list.get(i);
            if ( p != null ) {
                if ( p.getNome().equals( nome ) ) {
                    return i;
                }
            }
        }
        return -1;
    }
    
    private static boolean inserirNaLista(Passageiro passageiro, List<Passageiro> list) {
        int ind = primeiraPosicao( list );
        if ( ind != -1 ) { //se existe pos vazia
            list.set( ind, passageiro );
            return true;
        }
        return false;
    }

    private static boolean removerDaLista(String nome, List<Passageiro> list) {
        int ind = encontrarPorNome( nome, list );
        if ( ind != -1 ) { //se existe pass com o nome "name"
            // list[ind] = null;
            list.set( ind, null );
            return true;
        }
        return false;
    }


    public boolean inserir(Passageiro passageiro) {
        if ( encontrarPorNome( passageiro.getNome(), this.normalAssento ) != -1 ) {
            System.out.println("fail: " + passageiro.getNome() + " ja esta na topic");
            return false;
        }
        if ( encontrarPorNome( passageiro.getNome(), this.prioridadeAssento ) != -1 ) {
            System.out.println("fail: " + passageiro.getNome() + " ja esta na topic");
            return false;
        }

        if ( passageiro.isPrioridade() ) {
            if ( inserirNaLista( passageiro, this.prioridadeAssento ) ) {
                return true;
            }
            if ( inserirNaLista( passageiro, this.normalAssento ) ) {
                return true;
            }
        } else {
            if ( inserirNaLista( passageiro, this.normalAssento ) ) {
                return true;
            }
            if ( inserirNaLista( passageiro, this.prioridadeAssento ) ) {
                return true;
            }
        }
        
        System.out.println("fail: topic lotada");
        return false;
}
        // if ( findByName( pass.getName(), this.normalSeats ) != -1  ||
        //      findByName( pass.getName(), this.prioritySeats ) != -1 ) {
        //     System.out.println("fail: " + pass.getName() + " ja esta na topic");
        //     return false;
        // }
        
        // boolean achou = findByName( pass.getName(), this.normalSeats ) != -1;
        // if (!achou) {
        //     achou = findByName( pass.getName(), this.prioritySeats ) != -1;
        // }
        // if (achou) {
        //     System.out.println("fail: " + pass.getName() + " ja esta na topic");
        //     return false;
        // }

        // boolean inseriu = false;
        // if ( pass.isPriority() ) {
        //     inseriu = insertOnList( pass, this.prioritySeats );
        //     if ( !inseriu ) {
        //         inseriu = insertOnList( pass, this.normalSeats );
        //     }
        // } else {
        //     inseriu = insertOnList( pass, this.normalSeats );
        //     if ( !inseriu ) {
        //         inseriu = insertOnList( pass, this.prioritySeats );
        //     }
        // }
        
        // if (inseriu) {
        //     return true;
        // } else {
        //     System.out.println("fail: topic lotada");
        //     return false;
        // }
    

    public boolean remover(String nome) {
        if ( removerDaLista( nome, this.normalAssento ) ) {
            return true;
        }
        if ( removerDaLista( nome, this.prioridadeAssento ) ) {
            return true;
        }

        System.out.println("fail: " + nome + " nao esta na topic");
        return false;
        
        // boolean removeu = false;
        
        // removeu = removeFromList( name, this.normalSeats );
        // if (!removeu) {
        //     removeu = removeFromList( name, this.prioritySeats );
        // }
        
        // if ( removeu ) {
        //     return true;
        // } else {
        //     System.out.println("fail: " + name + " nao esta na topic");
        //     return false;
        // }
    }

    public String toString() {
        return "[" + Stream.concat(
            this.prioridadeAssento.stream().map(p -> ("@" + ((p == null)?(""):("" + p)))), 
            this.normalAssento.stream().map(p -> ("=" + ((p == null)?(""):("" + p)))))
            .collect(Collectors.joining(" ")) + "]";
    }
}

class Solver{
    public static void main(String[] args) {
        System.out.println("side_by_side=080");

        Scanner scanner = new Scanner(System.in);
        Topic topic = new Topic(0, 0);
        while(true){
            String line = scanner.nextLine();
            System.out.println("$" + line);
            String ui[] = line.split(" ");
            if(line.equals("end")) {
                break;
            } else if(ui[0].equals("init")) { //capacity qtdPriority
                topic = new Topic(Integer.parseInt(ui[1]), Integer.parseInt(ui[2]));
            } else if(ui[0].equals("show")) {
                System.out.println(topic);
            } else if(ui[0].equals("in")) {
                topic.inserir(new Passageiro(ui[1], Integer.parseInt(ui[2])));
            } else if(ui[0].equals("out")) {//value value
                topic.remover(ui[1]);
            } else {
                System.out.println("fail: comando invalido");
            }
        }
        scanner.close();
    }
}
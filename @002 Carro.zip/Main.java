// 1. Fiz tudo e consegui entender bem esses conceitos iniciais, mas ainda fiquei na duvida na parte dos THIS, vi uns videos e perguntei aos colegas como funcionava direito.
// 2. Fiz sozinho, mas nao estava passando em todos os testes, dai durante a aula o MARCOS VINICIUS E O GUILHERME me ajudaram a identificar o erro(no THIS).
// 3. entendi a questao e consegui acompanhar o raciocinio dela, mas preciso ainda abstrair os conceitos de POO
// 4. levei o tempo da aula e em casa em torno de 2h pra refazer e entender os conteudos.
import java.util.*;
import java.util.Scanner;

  class Carro{
    int pass;
    int passMax;
    int gas;
    int gasMax;
    int km;
    
    Carro(){
       this.passMax=2;
       this.gasMax=100;

        
    }
     
      Carro (int passMax, int gasMax){
        this.passMax=passMax;
        this.gasMax=gasMax;
    }  
        
    void enter(){
        if(this.pass< this.passMax){
                this.pass++;

        }
        else {
            System.out.println("fail: limite de pessoas atingido");
        }
    }
    void leave(){
        if(this.pass<=0){
            System.out.println("fail: nao ha ninguem no carro");
        }else{
            this.pass--;
        }
    }
    void fuel(int comb){
        this.gas+=comb;
        if(this.gas>this.gasMax){
            this.gas=this.gasMax;
        }
    }
    
    void drive(int km){
        if(this.pass<=0){
             System.out.println("fail: nao ha ninguem no carro");
        }
        else if(this.gas==0){
                        System.out.println("fail: tanque vazio");
        } else if( this.gas< km){
              System.out.println("fail: tanque vazio apos andar "+ this.gas + " km");
            this.km+= this.gas;
            this.gas=0;
        }else{
            this.km+=km;
            this.gas-=km;
        }
    }
    String show(){
        return
        "pass: " + this.pass +", " +
        //"passMax:" + this.passMax + "," +
        "gas: " + this.gas +", " +
        //"gasMax:"+ this.gasMax +"," +
        "km: " + this.km;
    }
    
}



/*public class Main {
    public static void main(String[] a) {
        Carro car = new Carro();
        car.show();
        
        //Carro car2 = new Carro(4, 5);
       // car2.show();
        
        //Carro car3 = new Carro(5, 200);
        //car3.show();
        
    }
}*/

public class Main {
    public static void main(String[] a) {
        Carro car = new Carro();
        
        while (true) {
            String line = input();
            write("$" + line);
            String[] args = line.split(" ");

            if      (args[0].equals("end"))   { break;                                }
            else if (args[0].equals("show"))  { System.out.println(car.show());              }
            else if (args[0].equals("enter")) { car.enter();                          }
            else if (args[0].equals("leave")) { car.leave();                          }
            else if (args[0].equals("drive")) { car.drive((int) number(args[1]));     }
            else if (args[0].equals("fuel"))  { car.fuel((int) number(args[1]));      }
            else                              { write("fail: comando invalido");}
        }
    }

     static Scanner scanner = new Scanner(System.in);
     static String  input()              { return scanner.nextLine(); }
     static double  number(String value) { return Double.parseDouble(value); }
     static void    write(String value)  { System.out.println(value); }
}









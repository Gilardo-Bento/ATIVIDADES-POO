// 1. Fiz tudo e mesmo assim ainda foi dificil entender bem esses conceitos iniciais,mas fiquei praticando e consegui acompanhar na aula.
// 2. Fiz junto com o senhor durante a aula e em casa tentei refazer e consegui, mas eu peguei todos os conceitos.
// 3. entendi o inicio de java pra objetos ate que bem, tive dificuldade para abstrair esse negocio de uma class ponto que contem um ponto
// 4. levei o tempo da aula e em casa em torno de 2h pra refazer e entender os conteudos.
import java.util.Scanner;

class Ponto {
    float x;
    float y;

    public Ponto(float x, float y) {
        this.x = x;
        this.y = y;
    }
}

class Circulo {
    
    
    Ponto centro;
    float raio;

    public Circulo(Ponto centro, float raio) {
        this.centro = centro;
        this.raio = raio;
    }

    public boolean pontoDentro(Ponto pnt) {
        float dist = (float) Math.sqrt((pnt.x - centro.x) * (pnt.x - centro.x) +
                                       (pnt.y - centro.y) * (pnt.y - centro.y));
        return dist <= raio;
    }
}

public class QuantosDentro {
    public static int contarPontosDentro(Ponto[] pontos, Circulo cir) {
        int qnt = 0;
        for (Ponto ponto : pontos) {
            if (cir.pontoDentro(ponto)) {
                qnt++;
            }
        }
        return qnt;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int Num = scanner.nextInt();
        Ponto[] pontos = new Ponto[Num];

        for (int i = 0; i < Num; i++) {
            pontos[i] = new Ponto(scanner.nextFloat(), scanner.nextFloat());
        }

        Circulo circulo = new Circulo(new Ponto(scanner.nextFloat(), scanner.nextFloat()), scanner.nextFloat());

        int pontosDentroCirculo = contarPontosDentro(pontos, circulo);
        System.out.println(+ pontosDentroCirculo);
    }
}

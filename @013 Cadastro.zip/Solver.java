// 1. Essa questao nao consegui fazer direito sozinho professor, precisei ir acompanhado a que foi feita em sala, fiquei confuso e tive que consultar a resolucao
//fiz tudo mas nao tava entendendo para fazer as extrações de fato, assisti algumas aulas para pegar o conceito.
//por isso ate demorei pegar a logica dessa questao.
// 3. entendi o inicio ate bem mas depois fiquei confuso ainda , to estudando pra aprender a logica de organizar as informacoes
// 4. levei o tempo da aula e em casa em torno de 5h pra refazer e buscar entender os conteudos novos repassados.
import java.util.*;
import java.text.DecimalFormat;

class Client {
    private String clientId;
    private ArrayList<Account> accounts;

    public Client(String clientId) {
        this.clientId = clientId;
        this.accounts = new ArrayList<Account>();
    }

    public void addAccount(Account acc) {
        this.accounts.add(acc);
    }

    public ArrayList<Account> getAccounts() {
        return this.accounts;
    }

    public String getClientId() {
        return this.clientId;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder( clientId + " [");
        for (int i = 0; i < accounts.size(); i++) {
            sb.append(accounts.get(i).getAccId());
            if (i < accounts.size() - 1) {
                sb.append(", ");
            }
        }
        sb.append("]");
        return sb.toString();
    }
    
}

abstract class Account {
    protected double balance;
    private static int nextAccountId = 0;
    protected int accId;
    protected String clientId;
    protected String typeId;

    public Account(String clientId, String typeId) {
        this.clientId = clientId;
        this.typeId = typeId;
        this.accId = nextAccountId++;
        this.balance = 0.0;
    }

    public void deposit(double value) {     //depositar
        balance += value;
    }

   public void withdraw(double value) throws Exception {
    if (value > balance) {
        throw new Exception("fail: saldo insuficiente");
    } else {
        balance -= value;
    }
}


   public void transfer(Account other, double value) {
    try {
        this.withdraw(value);  // Tenta sacar o valor da conta atual
        other.deposit(value);  // Tenta depositar o valor na outra conta
    } catch (Exception e) {
        System.out.println("fail: saldo insuficiente ou conta não encontrada");
    }
}


    @Override
    public String toString() {
        DecimalFormat d = new DecimalFormat("0.00");
        return accId + ":" + clientId + ":" + d.format(balance) + ":" + typeId;
    }

    public double getBalance() {
        return this.balance;
    }

    public int getAccId() {
        return this.accId;
    }

    public String getClientId() {
        return  this.clientId;
    }

    public String getTypeId() {
        return this.typeId;
    }

    public abstract void updateMonthly();
}

class CheckingAccount extends Account {     //CONTA CORRENTE
    protected double monthlyFee;
    public CheckingAccount(String clientId) {
        super(clientId, "CC");
        this.monthlyFee= 20.0;
    }

    @Override
    public void updateMonthly() {   //saldo mensal
        
        this.balance -= this.monthlyFee;
    }
}

class SavingsAccount extends Account {      //CONTA POUPANÇA
    protected double monthlyInterest;

    public SavingsAccount(String clientId) {
        super(clientId, "CP");
        this.monthlyInterest=0.01;
    }

    @Override
    public void updateMonthly() {
             this.balance +=   this.monthlyInterest * this.balance;

    }
}

class Agency {
    private Map<Integer, Account> accounts;
    private Map<String, Client> clients;

    private Account getAccount(int accountId) {
    Account account = this.accounts.get(accountId);
    if (account == null) {
        throw new RuntimeException("fail: conta nao encontrada");
    }
    return account;
}


    public Agency() {
        this.accounts = new HashMap<Integer,Account>();
       // this.clients = new HashMap<String,Client>();

        this.clients = new LinkedHashMap<String,Client>();
    }

    public void addClient(String clientId) {
        Client client = new Client(clientId);
      
        this.clients.put(clientId, client);

        CheckingAccount cc = new CheckingAccount(clientId); //conta corrente
        SavingsAccount cp = new SavingsAccount(clientId);   //conta poupança
        this.accounts.put(cc.getAccId(), cc);
        this.accounts.put(cp.getAccId(), cp);

        client.addAccount(cc);
        client.addAccount(cp);
    }

    public void deposit(int accId, double value) {
        Account account = getAccount(accId);
/*        this.getAccount(accId).deposit(value);
*/        if (account != null) {
            account.deposit(value);
        }
    }

   public void withdraw(int accId, double value) {  //retirar
    Account account = getAccount(accId);
    if (account != null) {
        try {
            account.withdraw(value);
        } catch (Exception e) {
            System.out.println(e.getMessage()); // Exibe a mensagem de erro da exceção
        }
    } else {
        System.out.println("fail: conta nao encontrada");
    }
}

    public void transfer(int fromAccId, int toAccId, double value) {
        Account fromAccount = getAccount(fromAccId);
        Account toAccount = getAccount(toAccId);

        if (fromAccount != null && toAccount != null) {
            fromAccount.transfer(toAccount, value);
        }
    }

    public void updateMonthly() {   //ATUALIZACAO MENSAL
        for (Account account : accounts.values()) {
            account.updateMonthly();
        }
    }

    @Override
    public String toString() {
        StringBuilder s = new StringBuilder("- Clients\n");
        for (Client client : clients.values()) {
            s.append(client).append("\n");
        }
        s.append("- Accounts\n");
        for (Account acc : accounts.values()) {
            s.append(acc).append("\n");
        }
        return s.toString();
    }
}

public class Solver {
    public static void main(String[] args) {
        Agency agency = new Agency();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            String line = input(scanner);
            println("$" + line);
            String[] arguments = line.split(" ");

            try {
                if (arguments[0].equals("end")) {
                    break;
                } else if (arguments[0].equals("show")) {
                    print(agency);
                } else if (arguments[0].equals("addCli")) {
                    agency.addClient(arguments[1]);
                } else if (arguments[0].equals("deposito")) {
                    agency.deposit(Integer.parseInt(arguments[1]), Double.parseDouble(arguments[2]));
                } else if (arguments[0].equals("saque")) {
                    agency.withdraw(Integer.parseInt(arguments[1]), Double.parseDouble(arguments[2]));
                } else if (arguments[0].equals("transf")) {
                    agency.transfer(Integer.parseInt(arguments[1]), Integer.parseInt(arguments[2]), Double.parseDouble(arguments[3]));
                } else if (arguments[0].equals("update")) {
                    agency.updateMonthly();
                } else {
                    println("fail: comando invalido");
                }
            } catch (Exception e) {
                println(e.getMessage());
            }
        }
    }

    private static String input(Scanner scanner) {
        return scanner.nextLine();
    }

    public static void println(Object value) {
        System.out.println(value);
    }

    public static void print(Object value) {
        System.out.print(value);
    }
}
